Collections
===========

These datastructures are used to implement the behaviour of various urllib3
components in a decoupled and application-agnostic design.

.. automodule:: urllib3._collections

    .. autoclass:: RecentlyUsedContainer
       :members:

    .. autoclass:: HTTPHeaderDict
       :members:
